g++ main.cpp -o main -lglfw -lGL -lX11 -lpthread -lXrandr -lXi -ldl
./main
