

int main( )
{
 printf("halo world"\n);
}